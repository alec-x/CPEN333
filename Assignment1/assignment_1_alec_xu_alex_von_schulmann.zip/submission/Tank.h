#pragma once

// Alex Von Schulmann 13975140
// Alec Xu 38108130

struct Tank {
	int fuelLevel;
};